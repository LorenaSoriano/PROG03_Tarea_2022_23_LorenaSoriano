package tarea03;

// Aquí tendrás que incluir los "import" que necesites

import libtarea3.Bombilla;
import libtarea3.Utilidades;
import java.time.LocalDate;



/**
 * Ejercicio 1: trabajo con bombillas
 * @author Nombre Lorena Soriano Hernández
 */
public class Ejercicio01 {

     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // 1.1. Declaración de tres variables referencia a objetos instancia de la clase Bombilla
        Bombilla b1 , b2, b3;
        
        // 1.2. Declaración de variable para dar formato de fecha hora 
        
        
        //----------------------------------------------
        //              Presentación
        //----------------------------------------------
        System.out.println("TRABAJO CON BOMBILLAS");
        System.out.println("--------------------");
        System.out.println();

        //----------------------------------------------
        //               Análisis inicial
        //----------------------------------------------        
        // 2. Consulta de valores iniciales
        System.out.println("1.-CONSULTA INICIAL DE VALORES GLOBALES");
        System.out.println("---------------------------------------");
        System.out.println();

        // 2.1. Número de bombillas creadas hasta el momento
        System.out.println("Número de bombillas creadas hasta el momento: " + Bombilla.getBombillasCreadas() + ".");

        // 2.2. Número de bombillas encendidas en este momento
        System.out.println("Número de bombillas encendidas en este momento: " + Bombilla.getBombillasEncendidas() + ".");
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        // En realidad no hay entrada de datos como tal dado que la información 
        // de entrada es fija y siempre la misma
        System.out.println("\n2.-CREACIÓN Y USO DE BOMBILLAS");
        System.out.println("------------------------------\n");

        // 3.- Instanciación de tres objetos Bombilla

        System.out.println("Creación de bombillas (constructores)");
        System.out.println("-------------------------------------");

        // 3.1.- Intento de crear una bombilla encendida con una potencia no válida (hay que gestionar la posible excepción)
        try {
            Bombilla bombillaFallida = new Bombilla(250);
        } catch (IllegalArgumentException ex) {
            System.out.printf ("Error: %s\n\n", ex.getMessage());
        }
        

        // 3.2.- Intento de crear una bombilla con estado por defecto y una potencia no válida (hay que gestionar la posible excepción)
        try {
            Bombilla bombillaFallida2 = new Bombilla(50);
        } catch (IllegalArgumentException ex) {
            System.out.printf ("Error: %s\n\n", ex.getMessage());
        }
        
        // 3.3.- Creación de una primera bombilla usando el constructor de dos parámetros
        System.out.println("Creando bombilla encendida con una portencia válida con un constructor con dos parámetros...");
        b1=new Bombilla(true,100);
        boolean estado1 =b1.getEstado();
        String x;
        if(estado1==true){
            x = "encendida";
        }else{
            x = "apagada";
        }
        System.out.println("Bombilla 1 creada, estado: Bombilla " + x + ". Se ha encendido " + b1.getVecesEncendida()+ " vez.");
        

        // 3.4.- Creación de una segunda bombilla encendida y potencia por defecto usando el constructor de un parámetro        
        b2=new Bombilla(true);
        boolean estado2 =b2.getEstado();
        if(estado2==true){
            x = "encendida";
        }else{
            x = "apagada";
        }
        System.out.println("Bombilla 2 creada, estado: Bombilla " + x + ". Se ha encendido " + b2.getVecesEncendida()+ " vez.");

        // 3.5.- Creación de una tercera bombilla usando el constructor sin parámetros        
        b3=new Bombilla();
        boolean estado3 =b3.getEstado();
        if(estado3==true){
            x = "encendida";
        }else{
            x = "apagada";
        }
        System.out.println("Bombilla 3 creada, estado: Bombilla " + x+ ". Se ha encendido " + b3.getVecesEncendida()+ " vez.\n");
        
        //----------------------------------------------
        //       Procesamiento + Salida de Resultados
        //----------------------------------------------
        // Dado que se va a ir mostrando información de salida a la vez que 
        // se van realizando operaciones, podemos considerar en este caso
        // que el procesamiento y la salida de resultado van unidos y "mezclados"
        
        // 4.- Operaciones con bombillas
        
        System.out.println("Manipulación de bombillas (métodos)");
        System.out.println("-----------------------------------");

        // 4.1.- Intento de encender una bombilla ya encendida
        System.out.println("Encendiendo la primera bombilla.");
        try{
            
                        
        }catch (IllegalArgumentException ex) {
            System.out.printf ("Error: %s\n\n", ex.getMessage());
        }
        
        // 4.2.- Conmutar la primera bombilla seis veces (utilizando un bucle)
        System.out.println("Conmutando el estado de la bombilla 1.");
        for (byte i = 1; i <= 6; i++) {
            System.out.printf("Estado de la Bombilla 1 %d: %d\n",i, b1.getEstado());
            System.out.printf("Esperando %d segundo...\n");
        }
        // 4.3.- Apagar la segunda bombilla
        
        // 4.4.- Encender la tercera bombilla
        
        
        // 5.- Obtención de información de la primera bombilla creada
        System.out.println ("\nPrueba de los getters de la primera bombilla creada:");
        System.out.println ("----------------------------------------------------");
        System.out.println("Bombilla 1");
        System.out.printf("Potencia: %2f W", b1.getPotencia());
        System.out.printf("Estado: %s\n", b1.getEstado());
        System.out.printf("Última vez que se encenió: %d\n", b1.getUltimaVezEncendida());
        System.out.printf("Número de veces encendida: %d veces\n", b1.getVecesEncendida());
        System.out.printf("Tiempo que lleva encendida %2f segundos\n", b1.getTiempoEncendida());
        System.out.printf("Potencia consumida: %2f Ws", b1.getPotenciaConsumida());
        
        //----------------------------------------------
        //               Análisis Final
        //----------------------------------------------        
        // 6. Consulta de valores finales
        System.out.println("3.-CONSULTA FINAL DE VALORES GLOBALES");
        System.out.println("-------------------------------------");
        System.out.println();

        // 6.1. Número de bombillas creadas hasta el momento
        System.out.printf("Número de bombillas credas hasta el momento: %d.", Bombilla.getBombillasCreadas());

        // 6.2. Número de bombillas encendidas en este momento
        System.out.printf("Número de bombillas encendidas hasta el momento: %d.", Bombilla.getBombillasEncendidas());

        System.out.println ();
	System.out.println ("Fin del programa.");
    }
    
}