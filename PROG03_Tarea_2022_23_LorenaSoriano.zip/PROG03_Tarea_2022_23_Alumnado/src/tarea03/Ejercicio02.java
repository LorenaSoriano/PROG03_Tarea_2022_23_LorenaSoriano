package tarea03;

// Aquí tendrás que incluir los "import" que necesites


/**
 * Ejercicio 2: Uso de la clase Bombo
 * @author Nombre Lorena Soriano Hernández
 */
public class Ejercicio02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Variables de entrada (bombos)

        // Variables de salida

        // Variables auxiliares
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        // En realidad no hay entrada de datos como tal dado que la información 
        // de entrada es fija y siempre la misma
        System.out.println("USO DE BOMBOS");
        System.out.println("-------------");
        System.out.println();

        //----------------------------------------------
        //      Procesamiento y salida de resultados
        //----------------------------------------------
        System.out.println("----------------------------------");
        System.out.println("CREACIÓN DE BOMBOS (CONSTRUCTORES)");
        System.out.println("----------------------------------");

        //1. Intentos de creación y llenado de bombos
        //1.1 Creación de bombos con capacidades no válidas
        //1.1.1 Intentamos crear un bombo con una capacidad no válida (inferior a la permitida)
        
                
        //1.1.2 Intentamos crear un bombo con una capacidad no válida (superior a la permitida)
        
                
        //1.2 Creación de bombos con capacidades válidas
        //1.2.1 Intentamos crear un bombo con la capacidad por omisión
        //usando para ello el constructor sin parámetros        
        
        
        //1.2.2 Intentamos crear un bombo con una capacidad válida
        //usando para ello el constructor con un parámetro
        
        



        //2. Pruebas de extracción
        System.out.println();
        System.out.println("----------------------");
        System.out.println("PRUEBAS DE EXTRACCIÓN:");
        System.out.println("----------------------");

        // 2.1 Extraemos todas las bolas del bombo creado
        System.out.println("PRUEBA 1: EXTRACCIÓN DE TODAS LAS BOLAS DE UN BOMBO:");
        System.out.println("----------------------------------------------------");
        System.out.println("Extrayendo todas las bolas del bombo...");

        // Vamos extrayendo una a una cada bola y vamos informando
        

        //Mostramos los resultados obtenidos


        //2.2 Reiniciamos el bombo para poder seguir extrayendo bolas y mostramos su estado   
        System.out.println("PRUEBA 2: REINICIO DEL BOMBO:");
        System.out.println("-----------------------------------------------------------------");

        
        // 2.3 Extraemos del bombo creado un número aleatorio de bolas entre 11 y 14 (ambos incluidos)
        System.out.println("PRUEBA 3: EXTRACCIÓN DE UN NÚMERO ALEATORIO DE BOLAS DE UN BOMBO:");
        System.out.println("-----------------------------------------------------------------");
        System.out.println("Extrayendo un número aleatorio de bolas...");
 
        // Vamos extrayendo las bolas y vamos informando
        

        // Mostramos los resultados finales obtenidos       
        
        
    }

}
