package tarea03;

// Aquí tendrás que incluir los "import" que necesites

import java.util.InputMismatchException;
import java.util.Scanner;



/**
 * Ejercicio 3: Contador de domingos.
 * @author Nombre Lorena Soriano Hernández
 */
public class Ejercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes


        // Variables de entrada
       int anio;
       boolean errorEntrada;

        // Variables de salida
        

        // Variables auxiliares
        
        
        // Objeto Scanner para lectura desde teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CONTADOR DE DOMINGOS");
        System.out.println("--------------------");

        // 1.- Leer y comprobar el año (entre 1900 y 2100), ambos incluidos
        do {
        System.out.println("Introduzca año (1900-2100):");
        try {
                anio = teclado.nextInt();
                errorEntrada = (anio < 1900 || anio > 2100);
            } catch (InputMismatchException ex) {
                System.err.println("Error de lectura: no es un número entero válido.");
                errorEntrada = true;
                teclado.nextLine(); // "Purgamos" lo que haya en el teclado, que es incorrecto
            }
        } while (errorEntrada);
        
 
        //----------------------------------------------
        //    Procesamiento + Salida de resultados  
        //----------------------------------------------
       
        
        // Iniciamos acumuladores
        
        
        // 2.- Recorremos todos los meses del año (bucle)
        
          
        // 2.1.- Para cada mes, recorremos cada una de las fechas que contiene y contamos cuántas hay que sean domingo

            
            
                        
        // 2.2.- Mostramos por pantalla la cantidad de domingos del mes (una línea por mes)
           
        
        // 2.3.- Incrementamos el cómputo global de domingos para el año
        
        
        // 3.- Mostramos por pantalla la cantidad de domingos totales
        
        
    }

}
